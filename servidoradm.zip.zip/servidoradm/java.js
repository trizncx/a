function toggleMenu(button) {
  const menu = document.getElementById("navMenu");
  button.classList.toggle("active");
  menu.classList.toggle("active");
}
